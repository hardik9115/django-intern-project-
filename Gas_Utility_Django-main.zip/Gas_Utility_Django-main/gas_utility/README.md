
Gas_Utility_Django
```
Gas_Utility_Django
├─ README.md
└─ gas_utility
   ├─ README.md
   ├─ consumer_services
   │  ├─ __init__.py
   │  ├─ __pycache__
   │  │  ├─ __init__.cpython-312.pyc
   │  │  ├─ admin.cpython-312.pyc
   │  │  ├─ apps.cpython-312.pyc
   │  │  ├─ forms.cpython-312.pyc
   │  │  ├─ models.cpython-312.pyc
   │  │  ├─ urls.cpython-312.pyc
   │  │  └─ views.cpython-312.pyc
   │  ├─ admin.py
   │  ├─ apps.py
   │  ├─ forms.py
   │  ├─ migrations
   │  │  ├─ 0001_initial.py
   │  │  ├─ 0002_alter_servicerequest_user.py
   │  │  ├─ __init__.py
   │  │  └─ __pycache__
   │  │     ├─ 0001_initial.cpython-312.pyc
   │  │     ├─ 0002_alter_servicerequest_user.cpython-312.pyc
   │  │     └─ __init__.cpython-312.pyc
   │  ├─ models.py
   │  ├─ templates
   │  │  ├─ base.html
   │  │  ├─ consumer_services
   │  │  │  ├─ account_information.html
   │  │  │  ├─ home.html
   │  │  │  ├─ request_status.html
   │  │  │  ├─ request_submitted.html
   │  │  │  └─ submit_request.html
   │  │  └─ registration
   │  │     └─ login.html
   │  ├─ tests.py
   │  ├─ urls.py
   │  └─ views.py
   ├─ db.sqlite3
   ├─ gas_utility
   │  ├─ __init__.py
   │  ├─ __pycache__
   │  │  ├─ __init__.cpython-312.pyc
   │  │  ├─ settings.cpython-312.pyc
   │  │  ├─ urls.cpython-312.pyc
   │  │  └─ wsgi.cpython-312.pyc
   │  ├─ asgi.py
   │  ├─ settings.py
   │  ├─ urls.py
   │  └─ wsgi.py
   └─ manage.py

```